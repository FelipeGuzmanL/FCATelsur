<footer class="footer">
  <div class="container-fluid">
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, hecho por
      <a href="https://www.felipeguzman.cl" target="_blank">Felipe Guzmán.</a>
    </div>
  </div>
</footer>