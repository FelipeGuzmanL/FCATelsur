<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fuid">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-tittle">Lista de Cables de Fibra Óptica de</h4>
                                    <div class="row">
                                        <div class="col-7 text-right d-felx">
                                            <form action="#" method="get">
                                                <div class="form-row">
                                                    <div class="col-sm-4 align-self-center" style="text-align: right">
                                                        <input type="text" class="form-control float-right" name="texto" value="<?php echo e($texto ?? ''); ?>" placeholder="Buscar...">
                                                    </div>
                                                    <div class="col-auto align-self-center">
                                                        <input type="submit" class="btn btn-primary float-right" value="Buscar">
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <p class="card-category">Datos de Cables de Fibra Óptica</p>
                                </div>
                                <div class="card-body">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success" role="success">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div class="row">
                                        <div class="col-12 text-right">
                                            <a href="<?php echo e(route('mufas.edit_mufa', $alerta)); ?>" class="btn btn-warning">Editar Alerta</a>
                                            <a href="<?php echo e(route('cable.mufas.index', $alerta->mufa)); ?>" class="btn btn-primary"><i class="material-icons">arrow_back</i></a>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class="text-primary">
                                                <th>Item</th>
                                                <th>Distancia K</th>
                                                <th>Ruta 5 K</th>
                                                <th>Ubicación</th>
                                                <th>Latitud</th>
                                                <th>Longitud</th>
                                                <th>Observaciones</th>
                                                <th>Fecha de creación</th>
                                                <th class="text-right">Acciones</th>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e($alerta->mufa->item); ?></td>
                                                    <td><?php echo e($alerta->mufa->distancia_k); ?></td>
                                                    <td><?php echo e($alerta->mufa->ruta5_k); ?></td>
                                                    <td><?php echo e($alerta->mufa->ubicacion); ?></td>
                                                    <td><?php echo e($alerta->mufa->latitud); ?></td>
                                                    <td><?php echo e($alerta->mufa->longitud); ?></td>
                                                    <td><?php echo e($alerta->mufa->observaciones); ?></td>
                                                    <td><?php echo e($alerta->mufa->fecha); ?></td>
                                                    <td class="td-actions text-right">
                                                        <a href="<?php echo e(route('cable.mufas.edit', [$alerta->mufa->cable, $alerta->mufa])); ?>" class="btn btn-primary"><i class="material-icons">edit</i></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table class="table">
                                            <thead class="text-primary">
                                                <th>Observación de la Alerta</th>
                                                <th>Severidad</th>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e($alerta->observacion); ?></td>
                                                    <?php if($alerta->gravedad->gravedad == 'Baja'): ?>
                                                        <td class="text-success"><?php echo e($alerta->gravedad->gravedad); ?></td>
                                                    <?php elseif($alerta->gravedad->gravedad == 'Media'): ?>
                                                        <td class="text-warning"><?php echo e($alerta->gravedad->gravedad); ?></td>
                                                    <?php elseif($alerta->gravedad->gravedad == 'Alta'): ?>
                                                        <td class="text-danger"><?php echo e($alerta->gravedad->gravedad); ?></td>
                                                    <?php endif; ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'cablestroncales', 'titlePage' => 'Lista de Alertas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoBitacora\resources\views/alertas/index_mufa.blade.php ENDPATH**/ ?>