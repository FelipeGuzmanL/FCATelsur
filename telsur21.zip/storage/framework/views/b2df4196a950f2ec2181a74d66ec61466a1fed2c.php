<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('mufas.update_mufa', $alerta)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-tittle">Cable</h4>
                            <p class="card-category">Actualizar datos</p>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 text-right">
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary"><i class="material-icons">arrow_back</i></a>
                                </div>
                            </div>
                            <div class="row">
                                <label for="observacion" class="col-sm-2 col-form-label">Observación</label>
                                <div class="col-sm-7">
                                    <textarea class="form-control" name="observacion" rows="10" placeholder="Observaciones sobre la alerta" required oninvalid="this.setCustomValidity('Ingrese una observación sobre la alerta')" oninput="this.setCustomValidity('')"/><?php echo e(old('descrpcion', $alerta->observacion)); ?></textarea>
                                    <?php if($errors->has('observacion')): ?>
                                        <span class="error text-danger" for="input-observacion"><?php echo e($errors -> first('observacion')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="id_gravedad" class="col-sm-2 col-form-label">Gravedad</label>
                                <div class="col-sm-7">
                                    <div class="form-group">
                                        <select class="form-control micoso" data-style="btn btn-link" id="micoso" name="id_gravedad">
                                        <?php $__currentLoopData = $gravedad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($grave->id); ?>" <?php echo e($grave->id == $mufa->alerta->id_gravedad ? 'selected' : ''); ?>><?php echo e($grave->gravedad); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                      </div>
                                </div>
                            </div>
                        <div class="card-footer ml-auto mr-auto">
                            <button type="submit" class="btn btn-warning"><?php echo e(__('Actualizar Alerta')); ?></button>
                        </div>
                    </div>
                </form>
                <script>
                    $("#micoso").select2({
                    });
                </script>
                <style>
                    .select2 {
                        width: 100% !important;
                    }
                </style>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'cablestroncales', 'titlePage' => 'Generar Alerta en Filamento'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoBitacora\resources\views/alertas/edit_mufa.blade.php ENDPATH**/ ?>