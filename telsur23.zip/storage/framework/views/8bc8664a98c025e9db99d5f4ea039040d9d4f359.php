<footer class="footer">
    <div class="container">
        <nav class="float-left">
        <!--ul>
            <li>
            <a href="https://www.creative-tim.com">
                <?php echo e(__('Creative Tim')); ?>

            </a>
            </li>
            <li>
            <a href="https://creative-tim.com/presentation">
                <?php echo e(__('About Us')); ?>

            </a>
            </li>
            <li>
            <a href="http://blog.creative-tim.com">
                <?php echo e(__('Blog')); ?>

            </a>
            </li>
            <li>
            <a href="https://www.creative-tim.com/license">
                <?php echo e(__('Licenses')); ?>

            </a>
            </li>
        </ul-->
        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, desarrollado por
        <a href="https://www.felipeguzman.cl" target="_blank">Felipe Guzmán</a>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\feli_\ProyectoBitacora\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>