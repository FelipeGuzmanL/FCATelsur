<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fuid">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-tittle">Mufas del cable <?php echo e($cable->sitio->abreviacion); ?> <?php echo e($cable->nombre_cable); ?></h4>
                                    <div class="row">
                                        <div class="col-7 text-right d-felx">
                                            <form action="<?php echo e(route('cable.mufas.index', $cable->id)); ?>" method="get">
                                                <div class="form-row">
                                                    <div class="col-sm-4 align-self-center" style="text-align: right">
                                                        <input type="text" class="form-control float-right" name="texto" value="<?php echo e($texto ?? ''); ?>" placeholder="Buscar...">
                                                    </div>
                                                    <div class="col-auto align-self-center">
                                                        <input type="submit" class="btn btn-primary float-right" value="Buscar">
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <p class="card-category">Mufas de Cables de Fibra Óptica</p>
                                </div>
                                <div class="card-body">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success text-center" role="success">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(session('warning')): ?>
                                        <div class="alert alert-warning text-center" role="warning">
                                            <?php echo e(session('warning')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div class="row">
                                        <div class="col-12 text-right">
                                            <a href="<?php echo e(route('cable.mufas.create', [$cable])); ?>" class="btn btn-primary">Añadir Mufa</a>
                                            <a href="<?php echo e(route('cablestroncales.index')); ?>" class="btn btn-primary"><i class="material-icons">arrow_back</i></a>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class="text-primary">
                                                <th>Item</th>
                                                <th>Distancia K</th>
                                                <th>Ruta 5 K</th>
                                                <th>Ubicación</th>
                                                <th>Latitud</th>
                                                <th>Longitud</th>
                                                <th>Observaciones</th>
                                                <th>Fecha de creación</th>
                                                <th class="text-right">Acciones</th>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $mufas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mufa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($mufa->item); ?></td>
                                                    <td><?php echo e($mufa->distancia_k); ?></td>
                                                    <td><?php echo e($mufa->ruta5_k); ?></td>
                                                    <td><?php echo e($mufa->ubicacion); ?></td>
                                                    <td><?php echo e($mufa->latitud); ?></td>
                                                    <td><?php echo e($mufa->longitud); ?></td>
                                                    <td><?php echo e($mufa->observaciones); ?></td>
                                                    <td><?php echo e($mufa->fecha); ?></td>
                                                    <td class="td-actions text-right">
                                                        <?php if( $mufa->alerta == NULL): ?>
                                                            <?php elseif( $mufa->alerta != NULL): ?>
                                                                <a href="<?php echo e(route('mufas.index_mufa', $mufa->alerta)); ?>" class="btn btn-warning"><i class="material-icons">warning</i></a>
                                                                <form action="<?php echo e(route('mufas.destroy_mufa', $mufa)); ?>" method="post" style="display: inline-block" onsubmit="return confirm('¿Está seguro de eliminar esta alerta?')">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button class="btn btn-warning" type="submit" rel="tooltip">
                                                                        <i class="material-icons">close</i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        <?php if( $mufa->link_gmaps == NULL): ?>
                                                            <?php elseif( $mufa->link_gmaps != NULL): ?>
                                                                <a href="<?php echo e($mufa->link_gmaps); ?>" target="_blank" class="btn btn-success"><i class="material-icons">location_on</i></a>
                                                            <?php endif; ?>
                                                        <a href="<?php echo e(route('cable.mufas.edit', [$cable, $mufa])); ?>" class="btn btn-primary"><i class="material-icons">edit</i></a>
                                                        <form action="<?php echo e(route('cable.mufas.destroy', [$cable,$mufa])); ?>" method="post" style="display: inline-block" onsubmit="return confirm('¿Estás seguro?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger" type="submit" rel="tooltip">
                                                            <i class="material-icons">close</i>
                                                        </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <div class="d-flex justify-content-center">
                                            <?php echo $mufas->links("pagination::bootstrap-4"); ?>

                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'cablestroncales', 'titlePage' => 'Mufas del Cable'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoBitacora\resources\views/mufas/index.blade.php ENDPATH**/ ?>