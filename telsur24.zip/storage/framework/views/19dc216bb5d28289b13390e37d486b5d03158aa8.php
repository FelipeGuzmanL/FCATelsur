<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('cable.mufas.store', [$cable])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-tittle">Agregar mufa del Cable <?php echo e($cable->sitio->abreviacion); ?> <?php echo e($cable->nombre_cable); ?></h4>
                            <p class="card-category">Ingresar datos de la mufa del Cable <?php echo e($cable->sitio->abreviacion); ?> <?php echo e($cable->nombre_cable); ?></p>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 text-right">
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary"><i class="material-icons">arrow_back</i></a>
                                </div>
                            </div>
                            <div class="row">
                                <label for="item" class="col-sm-2 col-form-label">Item</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="item" placeholder="Item" value="<?php echo e(old('item')); ?>">
                                    <?php if($errors->has('item')): ?>
                                        <span class="error text-danger" for="input-item"><?php echo e($errors -> first('item')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="distancia_k" class="col-sm-2 col-form-label">Distancia K</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="distancia_k" placeholder="Distancia en Kilometros" value="<?php echo e(old('distancia_k')); ?>">
                                    <?php if($errors->has('distancia_k')): ?>
                                        <span class="error text-danger" for="input-distancia_k"><?php echo e($errors -> first('distancia_k')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="ruta5_k" class="col-sm-2 col-form-label">Ruta 5 K</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="ruta5_k" placeholder="Distancia en Kilometros Ruta 5" value="<?php echo e(old('ruta5_k')); ?>">
                                    <?php if($errors->has('ruta5_k')): ?>
                                        <span class="error text-danger" for="input-ruta5_k"><?php echo e($errors -> first('ruta5_k')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="ubicacion" class="col-sm-2 col-form-label">Ubicación</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="ubicacion" placeholder="Dirección de la ubicación" value="<?php echo e(old('ubicacion')); ?>">
                                    <?php if($errors->has('ubicacion')): ?>
                                        <span class="error text-danger" for="input-ubicacion"><?php echo e($errors -> first('ubicacion')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="latitud" class="col-sm-2 col-form-label">Latitud</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="latitud" placeholder="Coordenadas Latitud" value="<?php echo e(old('latitud')); ?>">
                                    <?php if($errors->has('latitud')): ?>
                                        <span class="error text-danger" for="input-latitud"><?php echo e($errors -> first('latitud')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="longitud" class="col-sm-2 col-form-label">Longitud</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="longitud" placeholder="Coordenadas longitud" value="<?php echo e(old('longitud')); ?>">
                                    <?php if($errors->has('longitud')): ?>
                                        <span class="error text-danger" for="input-longitud"><?php echo e($errors -> first('longitud')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="fecha" class="col-sm-2 col-form-label">Fecha de creación</label>
                                <div class="col-sm-7">
                                    <input type="date" class="form-control" name="fecha">
                                </div>
                            </div>
                            <div class="row">
                                <label for="observaciones" class="col-sm-2 col-form-label">Observaciones</label>
                                <div class="col-sm-7">
                                    <textarea class="form-control" name="observaciones" rows="3" placeholder="Observaciones"><?php echo e(old('observaciones')); ?></textarea>
                                    <?php if($errors->has('observaciones')): ?>
                                        <span class="error text-danger" for="input-observaciones"><?php echo e($errors -> first('observaciones')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <label for="link_gmaps" class="col-sm-2 col-form-label">Link Gmaps</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="link_gmaps" placeholder="Coordenadas link_gmaps" value="<?php echo e(old('link_gmaps')); ?>">
                                    <?php if($errors->has('link_gmaps')): ?>
                                        <span class="error text-danger" for="input-link_gmaps"><?php echo e($errors -> first('link_gmaps')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <div class="card-footer ml-auto mr-auto">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
            <script>
                $("#sitios").select2({
                });
            </script>
            <script>
                $("#tipocables").select2({
                });
            </script>
            <style>
                .select2 {
                    width: 100% !important;
                }
            </style>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'cablestroncales', 'titlePage' => 'Mufa del Cable'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feli_\ProyectoBitacora\resources\views/mufas/create.blade.php ENDPATH**/ ?>