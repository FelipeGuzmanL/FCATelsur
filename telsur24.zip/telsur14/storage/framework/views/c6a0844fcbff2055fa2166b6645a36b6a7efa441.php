<footer class="footer">
  <div class="container-fluid">
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, desarrollado por
      <a href="https://www.felipeguzman.cl" target="_blank">Felipe Guzmán.</a>
    </div>
  </div>
</footer><?php /**PATH C:\Users\feli_\BitacorasVehiculosTelsur\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>